<?php

// header('Access-Control-Allow-Headers: Content-Type'); // Allow Content-Type header

// header("Access-Control-Allow-Origin: *");  // Or specify your frontend domain
// header("Access-Control-Allow-Methods: POST, OPTIONS");
// header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

require_once('../config/config.php');
require_once('../config/database.php');

// if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { // handle options
//     http_response_code(200);
//     exit();
//   }

// Define configuration options
$allowedMethods = ['GET'];
$maxPostsPerPage = 10;

// implement basic pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $maxPostsPerPage;

// Query to count total posts
$countQuery = "SELECT COUNT(*) AS totalPosts FROM blog_posts";
$countResult = mysqli_query($conn, $countQuery);
$countRow = mysqli_fetch_assoc($countResult);
$totalPosts = $countRow['totalPosts'];

// Query to get all blog posts with pagination and ordering
$query = "SELECT * FROM blog_posts ORDER BY publish_date DESC LIMIT $offset, $maxPostsPerPage";
$result = mysqli_query($conn, $query);

// Check status of pginated posts query
if (!$result) {
    http_response_code(500); // Internal Server Error
    echo json_encode(['message' => 'Error querying the database fro paginated posts: ' . mysqli_error($conn)]);
    mysqli_close($conn);
    exit();
}

// Convert query result into an associative array
$posts = mysqli_fetch_all($result, MYSQLI_ASSOC);

// Check if there are posts
if (empty($posts)) {
    http_response_code(404); // Not found
    echo json_encode(['message' => 'No posts found', 'totalPosts' => $totalPosts]);
}
else {
    http_response_code(200); // Ok
    echo json_encode(['posts' => $posts, 'totalPosts' => $totalPosts]);
}

// Close database connection
mysqli_close($conn);

?>