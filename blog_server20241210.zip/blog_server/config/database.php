<?php

// Database configuration
$dbHost = "localhost";
$dbUsername = "root"
$dbPassword = "123456";
$dbName = "simple_blog_app"

// Create database connection

$conn = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>